chmod 777 first
IN="$1.graph"
./first < $IN > $"$1.satinput"
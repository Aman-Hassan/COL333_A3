g++ Part1.cpp -o first 
g++ Part2.cpp -o second 
g++ output_graph.cpp -o result
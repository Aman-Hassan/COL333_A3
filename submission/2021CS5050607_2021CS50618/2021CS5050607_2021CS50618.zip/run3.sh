chmod 777 second 
./second $1